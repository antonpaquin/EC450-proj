/*
 * comm.h
 *
 *  Created on: Apr 30, 2017
 *      Author: wchen
 */

#ifndef COMM_H_
#define COMM_H_
#include "driverlib.h"



static volatile unsigned int ii;
static volatile unsigned jj=0;

void comm_setup();
#endif /* COMM_H_ */
